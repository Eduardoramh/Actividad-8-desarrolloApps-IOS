//
//  ContentView.swift
//  Actividad8_ERH
//
//  Created by user183810 on 3/22/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
